export const CONFIG = {
    SUPABASE_URL: 'https://zqoriuatdgiiowdfmezn.supabase.co',
    SUPABASE_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inpxb3JpdWF0ZGdpaW93ZGZtZXpuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA1MjYxODIsImV4cCI6MjA4NjEwMjE4Mn0.4_7CwhNsX0JdTdEfxYo-2dwQTvnfRuwv-eljjgMQKYg'
};
